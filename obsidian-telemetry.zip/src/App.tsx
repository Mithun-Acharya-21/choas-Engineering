import { useCallback, useEffect, useMemo, useState } from 'react';
import { ChaosLabScreen } from './components/ChaosLabScreen';
import { CommandPalette } from './components/CommandPalette';
import { LogsTracesScreen } from './components/LogsTracesScreen';
import { ServiceInspectorDrawer } from './components/ServiceInspectorDrawer';
import { Sidebar } from './components/Sidebar';
import { TelemetryOverviewScreen } from './components/TelemetryOverviewScreen';
import { TopBar } from './components/TopBar';
import { TopologyScreen } from './components/TopologyScreen';
import {
  buildTraceSpans,
  FAULT_TYPE_META,
  generateInitialTelemetrySeries,
  INITIAL_EXPERIMENTS,
  INITIAL_LOGS,
  INITIAL_SERVICES,
} from './data/mockTelemetry';
import {
  ChaosExperiment,
  ClusterId,
  FaultType,
  LogEntry,
  ScreenId,
  ServiceNode,
  TelemetryPoint,
  TimeRange,
} from './types/telemetry';

function recomputeServicesFromExperiments(
  baseServices: ServiceNode[],
  experiments: ChaosExperiment[],
  cluster: ClusterId,
  jitterSeed: number
): ServiceNode[] {
  const activeExps = experiments.filter((e) => e.status === 'running');

  return baseServices.map((svc, idx) => {
    const targeting = activeExps.filter((e) => e.targetServiceId === svc.id);
    const wave = Math.sin(jitterSeed * 0.7 + idx * 1.3);

    if (targeting.length === 0) {
      const p99 = Number(Math.max(2, svc.baseP99Ms + wave * 2.4).toFixed(1));
      return {
        ...svc,
        cluster,
        status: 'healthy',
        p99Ms: p99,
        p95Ms: Number((p99 * 0.62).toFixed(1)),
        p50Ms: Number((p99 * 0.28).toFixed(1)),
        errorRatePct: Number(Math.max(0, svc.baseErrorRatePct + Math.abs(wave) * 0.01).toFixed(2)),
        rps: Math.round(svc.baseRps + wave * (svc.baseRps * 0.025)),
        podsReady: svc.podsTotal,
        cpuPct: Math.min(95, Math.max(18, Math.round(38 + idx * 4 + wave * 3))),
      };
    }

    let latencyBoost = 0;
    let errorBoost = 0;
    let cpuBoost = 0;
    let podLoss = 0;
    let isCritical = false;

    targeting.forEach((exp) => {
      const scale = exp.blastRadiusPct / 100;
      if (exp.faultType === 'latency') {
        latencyBoost += exp.magnitude * (0.85 + scale * 0.5);
        errorBoost += 0.55 * scale;
      } else if (exp.faultType === 'packet_loss') {
        latencyBoost += exp.magnitude * 7.5;
        errorBoost += exp.magnitude * 0.14 * scale;
        if (exp.magnitude >= 15) isCritical = true;
      } else if (exp.faultType === 'cpu_pressure') {
        cpuBoost += Math.round(exp.magnitude * 0.55);
        latencyBoost += exp.magnitude * 2.4;
        errorBoost += 0.45 * scale;
      } else if (exp.faultType === 'pod_kill') {
        podLoss = Math.min(svc.podsTotal - 1, Math.max(1, Math.round(svc.podsTotal * scale)));
        latencyBoost += 260;
        errorBoost += 2.15;
        isCritical = true;
      } else if (exp.faultType === 'dns_blackhole') {
        latencyBoost += 310;
        errorBoost += (exp.magnitude / 100) * 4.5;
        isCritical = true;
      }
    });

    const p99 = Number((svc.baseP99Ms + latencyBoost + wave * 12).toFixed(1));
    const errorRatePct = Number((svc.baseErrorRatePct + errorBoost + Math.abs(wave) * 0.15).toFixed(2));
    if (errorRatePct >= 1.5) isCritical = true;

    return {
      ...svc,
      cluster,
      status: isCritical ? 'critical' : 'injecting',
      p99Ms: p99,
      p95Ms: Number((p99 * 0.61).toFixed(1)),
      p50Ms: Number((p99 * 0.14).toFixed(1)),
      errorRatePct,
      rps: Math.max(120, Math.round(svc.baseRps * (isCritical ? 0.86 : 0.96) + wave * 80)),
      podsReady: Math.max(1, svc.podsTotal - podLoss),
      cpuPct: Math.min(99, Math.max(40, 52 + cpuBoost + Math.round(wave * 4))),
    };
  });
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ScreenId>('telemetry');
  const [cluster, setCluster] = useState<ClusterId>('prod-us-east-1');
  const [timeRange, setTimeRange] = useState<TimeRange>('15m');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [isLive, setIsLive] = useState(true);
  const [commandOpen, setCommandOpen] = useState(false);

  const [experiments, setExperiments] = useState<ChaosExperiment[]>(INITIAL_EXPERIMENTS);
  const [services, setServices] = useState<ServiceNode[]>(INITIAL_SERVICES);
  const [series, setSeries] = useState<TelemetryPoint[]>(() => generateInitialTelemetrySeries());
  const [logs, setLogs] = useState<LogEntry[]>(INITIAL_LOGS);

  const [inspectedServiceId, setInspectedServiceId] = useState<string | null>(null);
  const [topologySelectedId, setTopologySelectedId] = useState<string>('checkout-core');
  const [logFilterSeed, setLogFilterSeed] = useState<string>('');
  const [tickCount, setTickCount] = useState(1);

  const runningFaultCount = useMemo(
    () => experiments.filter((e) => e.status === 'running').length,
    [experiments]
  );

  const inspectedService = useMemo(
    () => services.find((s) => s.id === inspectedServiceId) ?? null,
    [services, inspectedServiceId]
  );

  // Global Cmd+K shortcut
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Recompute services when cluster changes
  const handleSelectCluster = (nextCluster: ClusterId) => {
    setCluster(nextCluster);
    setServices((prev) => recomputeServicesFromExperiments(prev, experiments, nextCluster, tickCount));
  };

  // Live 2s telemetry & chaos countdown engine
  useEffect(() => {
    if (!isLive) return;
    const timer = window.setInterval(() => {
      setTickCount((c) => c + 1);
    }, 2000);
    return () => window.clearInterval(timer);
  }, [isLive]);

  useEffect(() => {
    if (tickCount === 1) return;

    setExperiments((prevExps) => {
      let completedNow: ChaosExperiment[] = [];
      const nextExps = prevExps.map((exp) => {
        if (exp.status !== 'running') return exp;
        const nextRem = Math.max(0, exp.remainingSec - 2);
        if (nextRem === 0) {
          const done: ChaosExperiment = { ...exp, remainingSec: 0, status: 'completed' };
          completedNow.push(done);
          return done;
        }
        return { ...exp, remainingSec: nextRem };
      });

      const nextServices = recomputeServicesFromExperiments(
        INITIAL_SERVICES,
        nextExps,
        cluster,
        tickCount
      );
      setServices(nextServices);

      // Append live telemetry sample
      const faultActive = nextExps.some((e) => e.status === 'running');
      const maxP99 = Math.max(...nextServices.map((s) => s.p99Ms));
      const weightedP99 = faultActive
        ? Number((maxP99 * 0.58 + Math.sin(tickCount * 0.8) * 14).toFixed(1))
        : Number((58 + Math.sin(tickCount * 0.5) * 5).toFixed(1));
      const totalRps = nextServices.reduce((acc, s) => acc + s.rps, 0);
      const weightedErr =
        totalRps > 0
          ? Number(
              (
                nextServices.reduce((acc, s) => acc + s.errorRatePct * s.rps, 0) / totalRps
              ).toFixed(2)
            )
          : 0.04;

      const nowIso = new Date().toISOString();
      const nextPoint: TelemetryPoint = {
        timestamp: nowIso.slice(11, 19),
        p50: Number((weightedP99 * 0.14).toFixed(1)),
        p95: Number((weightedP99 * 0.59).toFixed(1)),
        p99: weightedP99,
        baselineP99: Number((62 + Math.sin(tickCount * 0.4) * 4).toFixed(1)),
        rps: totalRps,
        errorRate: weightedErr,
        faultActive,
      };
      setSeries((prev) => [...prev.slice(-35), nextPoint]);

      // Emit periodic live logs
      if (tickCount % 2 === 0 || completedNow.length > 0) {
        const degraded = nextServices.find((s) => s.status !== 'healthy') ?? nextServices[0];
        const isCrit = degraded.status === 'critical';
        const isWarn = degraded.status === 'injecting';
        const traceId = `tr-${Math.random().toString(16).slice(2, 12)}`;
        const dur = Math.round(degraded.p99Ms);

        const newLog: LogEntry = {
          id: `log-${Date.now()}-${tickCount}`,
          timestampIso: nowIso,
          level: completedNow.length > 0 ? 'INFO' : isCrit ? 'CRIT' : isWarn ? 'WARN' : 'INFO',
          service: completedNow.length > 0 ? completedNow[0].targetServiceName : degraded.name,
          cluster,
          traceId,
          durationMs: dur,
          message:
            completedNow.length > 0
              ? `experiment_completed: ${completedNow[0].name} converged cleanly; steady state restored`
              : isCrit
              ? `slo_burn_alert: ${degraded.name} 5xx=${degraded.errorRatePct.toFixed(2)}% p99=${degraded.p99Ms.toFixed(0)}ms`
              : isWarn
              ? `fault_active_probe: ${degraded.name} synthetic delay observed at mesh sidecar`
              : `health_probe_ok: envoy upstream cluster ${degraded.name} 200 OK`,
          metadata: {
            cluster,
            'p99.ms': degraded.p99Ms,
            'pods.ready': `${degraded.podsReady}/${degraded.podsTotal}`,
          },
          spans: buildTraceSpans(degraded.name, isCrit, dur),
        };

        setLogs((prev) => [newLog, ...prev].slice(0, 120));
      }

      return nextExps;
    });
  }, [tickCount, cluster]);

  const handleLaunchExperiment = useCallback(
    (payload: {
      name: string;
      targetServiceId: string;
      faultType: FaultType;
      magnitude: number;
      blastRadiusPct: number;
      durationSec: number;
      hypothesis: string;
    }) => {
      const svc = services.find((s) => s.id === payload.targetServiceId) ?? services[0];
      const meta = FAULT_TYPE_META[payload.faultType];
      const nowIso = new Date().toISOString();
      const newExp: ChaosExperiment = {
        id: `exp-${Math.floor(9413 + Math.random() * 500)}`,
        name: payload.name,
        targetServiceId: svc.id,
        targetServiceName: svc.name,
        cluster,
        faultType: payload.faultType,
        magnitude: payload.magnitude,
        magnitudeUnit: meta.unit,
        blastRadiusPct: payload.blastRadiusPct,
        durationSec: payload.durationSec,
        remainingSec: payload.durationSec,
        status: 'running',
        startedAt: `${nowIso.slice(11, 19)} UTC`,
        hypothesis: payload.hypothesis,
        impactDeltaP99Pct: Number((payload.magnitude * 0.9 + payload.blastRadiusPct * 1.4).toFixed(1)),
      };

      setExperiments((prev) => {
        const next = [newExp, ...prev];
        setServices(recomputeServicesFromExperiments(INITIAL_SERVICES, next, cluster, tickCount + 1));
        return next;
      });

      const launchLog: LogEntry = {
        id: `log-launch-${Date.now()}`,
        timestampIso: nowIso,
        level: 'WARN',
        service: svc.name,
        cluster,
        traceId: `tr-${Math.random().toString(16).slice(2, 12)}`,
        durationMs: Math.round(svc.p99Ms + 120),
        message: `chaos_injected: started ${newExp.name} (${newExp.magnitude}${newExp.magnitudeUnit} @ ${newExp.blastRadiusPct}% blast)`,
        metadata: { experiment: newExp.id, vector: newExp.faultType, target: svc.name },
        spans: buildTraceSpans(svc.name, false, Math.round(svc.p99Ms + 120)),
      };
      setLogs((prev) => [launchLog, ...prev]);
    },
    [services, cluster, tickCount]
  );

  const handleHaltExperiment = useCallback(
    (experimentId: string) => {
      const nowIso = new Date().toISOString();
      setExperiments((prev) => {
        const targetExp = prev.find((e) => e.id === experimentId);
        const next = prev.map((e) =>
          e.id === experimentId ? { ...e, status: 'halted' as const, remainingSec: 0 } : e
        );
        setServices(recomputeServicesFromExperiments(INITIAL_SERVICES, next, cluster, tickCount + 1));
        if (targetExp) {
          setLogs((l) => [
            {
              id: `log-halt-${Date.now()}`,
              timestampIso: nowIso,
              level: 'INFO',
              service: targetExp.targetServiceName,
              cluster,
              traceId: `tr-${Math.random().toString(16).slice(2, 12)}`,
              durationMs: 24,
              message: `experiment_halted: ${targetExp.name} aborted by operator; tc-netem rules flushed`,
              metadata: { experiment: targetExp.id, operator: 'sre-oncall' },
              spans: buildTraceSpans(targetExp.targetServiceName, false, 24),
            },
            ...l,
          ]);
        }
        return next;
      });
    },
    [cluster, tickCount]
  );

  const handleHaltAllFaults = useCallback(() => {
    const nowIso = new Date().toISOString();
    setExperiments((prev) => {
      const next = prev.map((e) =>
        e.status === 'running' ? { ...e, status: 'halted' as const, remainingSec: 0 } : e
      );
      setServices(recomputeServicesFromExperiments(INITIAL_SERVICES, next, cluster, tickCount + 1));
      return next;
    });
    setLogs((prev) => [
      {
        id: `log-halt-all-${Date.now()}`,
        timestampIso: nowIso,
        level: 'WARN',
        service: 'api-gateway',
        cluster,
        traceId: `tr-${Math.random().toString(16).slice(2, 12)}`,
        durationMs: 18,
        message: 'emergency_kill_switch: halted all active chaos experiments across cluster mesh',
        metadata: { cluster, action: 'halt_all' },
        spans: buildTraceSpans('api-gateway', false, 18),
      },
      ...prev,
    ]);
  }, [cluster, tickCount]);

  const handleQuickInjectLatency = useCallback(
    (serviceId: string) => {
      const svc = services.find((s) => s.id === serviceId);
      if (!svc) return;
      handleLaunchExperiment({
        name: `${svc.name}-quick-latency-200ms`,
        targetServiceId: svc.id,
        faultType: 'latency',
        magnitude: 200,
        blastRadiusPct: 30,
        durationSec: 180,
        hypothesis: `Quick +200ms egress fault check on ${svc.name}.`,
      });
    },
    [services, handleLaunchExperiment]
  );

  const handleHaltServiceFaults = useCallback(
    (serviceId: string) => {
      const runningForService = experiments.filter(
        (e) => e.status === 'running' && e.targetServiceId === serviceId
      );
      runningForService.forEach((e) => handleHaltExperiment(e.id));
    },
    [experiments, handleHaltExperiment]
  );

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#09090b] text-[#fafafa]">
      <Sidebar
        activeScreen={activeScreen}
        onSelectScreen={setActiveScreen}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed((c) => !c)}
        cluster={cluster}
        onSelectCluster={handleSelectCluster}
        runningFaultCount={runningFaultCount}
        isLive={isLive}
        onToggleLive={() => setIsLive((l) => !l)}
        mobileOpen={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <TopBar
          cluster={cluster}
          activeScreen={activeScreen}
          timeRange={timeRange}
          onSelectTimeRange={setTimeRange}
          runningFaultCount={runningFaultCount}
          onHaltAllFaults={handleHaltAllFaults}
          onOpenCommandPalette={() => setCommandOpen(true)}
          onOpenMobileNav={() => setMobileNavOpen(true)}
        />

        <main className="flex-1 overflow-y-auto">
          {activeScreen === 'telemetry' && (
            <TelemetryOverviewScreen
              cluster={cluster}
              timeRange={timeRange}
              services={services}
              series={series}
              experiments={experiments}
              onSelectService={(svc) => setInspectedServiceId(svc.id)}
              onNavigate={setActiveScreen}
            />
          )}

          {activeScreen === 'chaos' && (
            <ChaosLabScreen
              cluster={cluster}
              services={services}
              experiments={experiments}
              onLaunchExperiment={handleLaunchExperiment}
              onHaltExperiment={handleHaltExperiment}
              onInspectService={(svc) => setInspectedServiceId(svc.id)}
            />
          )}

          {activeScreen === 'topology' && (
            <TopologyScreen
              services={services}
              experiments={experiments}
              selectedServiceId={topologySelectedId}
              onSelectServiceId={setTopologySelectedId}
              onQuickInjectLatency={handleQuickInjectLatency}
              onHaltServiceFaults={handleHaltServiceFaults}
              onViewLogsForService={(svcName) => {
                setLogFilterSeed(`service:${svcName}`);
                setActiveScreen('logs');
              }}
            />
          )}

          {activeScreen === 'logs' && (
            <LogsTracesScreen
              logs={logs}
              initialFilter={logFilterSeed}
              onClearFilter={() => setLogFilterSeed('')}
              onClearLogs={() => setLogs([])}
            />
          )}
        </main>
      </div>

      <ServiceInspectorDrawer
        service={inspectedService}
        experiments={experiments}
        onClose={() => setInspectedServiceId(null)}
        onQuickInjectLatency={handleQuickInjectLatency}
        onHaltServiceFaults={handleHaltServiceFaults}
        onOpenTopology={(id) => {
          setTopologySelectedId(id);
          setActiveScreen('topology');
        }}
        onOpenLogs={(name) => {
          setLogFilterSeed(`service:${name}`);
          setActiveScreen('logs');
        }}
      />

      <CommandPalette
        open={commandOpen}
        onClose={() => setCommandOpen(false)}
        services={services}
        isLive={isLive}
        runningFaultCount={runningFaultCount}
        onNavigate={setActiveScreen}
        onInspectService={(svc) => setInspectedServiceId(svc.id)}
        onToggleLive={() => setIsLive((l) => !l)}
        onHaltAllFaults={handleHaltAllFaults}
      />
    </div>
  );
}
