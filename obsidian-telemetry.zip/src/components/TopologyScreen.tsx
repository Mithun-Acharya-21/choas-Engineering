import React, { useMemo, useState } from 'react';
import { Flame, Maximize2, OctagonAlert, Terminal, ZoomIn, ZoomOut } from 'lucide-react';
import { ChaosExperiment, ServiceNode } from '../types/telemetry';
import { StatusBadge } from './StatusBadge';

interface TopologyScreenProps {
  services: ServiceNode[];
  experiments: ChaosExperiment[];
  selectedServiceId: string;
  onSelectServiceId: (id: string) => void;
  onQuickInjectLatency: (serviceId: string) => void;
  onHaltServiceFaults: (serviceId: string) => void;
  onViewLogsForService: (serviceName: string) => void;
}

const NODE_W = 196;
const NODE_H = 84;

export const TopologyScreen: React.FC<TopologyScreenProps> = ({
  services,
  experiments,
  selectedServiceId,
  onSelectServiceId,
  onQuickInjectLatency,
  onHaltServiceFaults,
  onViewLogsForService,
}) => {
  const [zoom, setZoom] = useState(1);
  const [tierFilter, setTierFilter] = useState<'all' | 'ingress' | 'compute' | 'data'>('all');

  const selectedService =
    services.find((s) => s.id === selectedServiceId) ?? services[0];

  const upstreamCallers = useMemo(
    () => services.filter((s) => s.dependencies.includes(selectedService.id)),
    [services, selectedService]
  );

  const downstreamDeps = useMemo(
    () => services.filter((s) => selectedService.dependencies.includes(s.id)),
    [services, selectedService]
  );

  const activeNodeExperiments = useMemo(
    () =>
      experiments.filter(
        (e) => e.status === 'running' && e.targetServiceId === selectedService.id
      ),
    [experiments, selectedService]
  );

  const edges = useMemo(() => {
    const list: { from: ServiceNode; to: ServiceNode }[] = [];
    services.forEach((src) => {
      src.dependencies.forEach((depId) => {
        const dst = services.find((s) => s.id === depId);
        if (dst) list.push({ from: src, to: dst });
      });
    });
    return list;
  }, [services]);

  const statusBorder = (svc: ServiceNode, isSelected: boolean) => {
    if (svc.status === 'critical') return '#f43f5e';
    if (svc.status === 'injecting') return '#f59e0b';
    if (isSelected) return '#6366f1';
    return '#27272a';
  };

  return (
    <div className="flex h-[calc(100vh-48px)] flex-col xl:flex-row overflow-hidden">
      {/* Left: Interactive Mesh Graph Canvas */}
      <div className="relative flex-1 overflow-auto bg-[#09090b] p-4">
        {/* Top Floating Controls */}
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h1 className="font-display text-[20px] font-semibold tracking-[-0.02em] text-[#fafafa]">
              Service Mesh Topology
            </h1>
            <p className="font-mono text-[11px] text-[#71717a]">
              Click any node to inspect upstream callers, pod saturation, and fault blasts
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Tier Highlight */}
            <div className="flex items-center rounded border border-[#27272a] bg-[#111113] p-0.5">
              {(['all', 'ingress', 'compute', 'data'] as const).map((tier) => (
                <button
                  key={tier}
                  type="button"
                  onClick={() => setTierFilter(tier)}
                  className={`h-6 rounded-[3px] px-2 font-mono text-[10px] uppercase tracking-[0.04em] transition-colors whitespace-nowrap shrink-0 ${
                    tierFilter === tier
                      ? 'bg-[#202024] text-[#fafafa]'
                      : 'text-[#71717a] hover:text-[#a1a1aa]'
                  }`}
                >
                  {tier}
                </button>
              ))}
            </div>

            {/* Zoom Controls */}
            <div className="flex items-center rounded border border-[#27272a] bg-[#18181b]">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(0.7, Number((z - 0.1).toFixed(1))))}
                aria-label="Zoom out"
                className="flex h-7 w-7 items-center justify-center border-r border-[#27272a] text-[#a1a1aa] hover:bg-[#202024] hover:text-[#fafafa]"
              >
                <ZoomOut className="h-3.5 w-3.5" />
              </button>
              <span className="px-2 font-mono text-[11px] text-[#a1a1aa] tabular-nums">
                {Math.round(zoom * 100)}%
              </span>
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(1.3, Number((z + 0.1).toFixed(1))))}
                aria-label="Zoom in"
                className="flex h-7 w-7 items-center justify-center border-l border-[#27272a] text-[#a1a1aa] hover:bg-[#202024] hover:text-[#fafafa]"
              >
                <ZoomIn className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setZoom(1)}
                aria-label="Reset zoom"
                className="flex h-7 w-7 items-center justify-center border-l border-[#27272a] text-[#a1a1aa] hover:bg-[#202024] hover:text-[#fafafa]"
              >
                <Maximize2 className="h-3 w-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Graph Viewport Stage */}
        <div
          className="relative min-h-[470px] w-full overflow-auto rounded-lg border border-[#27272a] bg-[#111113]"
          style={{
            backgroundImage: 'radial-gradient(#27272a 1px, transparent 1px)',
            backgroundSize: '20px 20px',
          }}
        >
          <div
            className="relative origin-top-left transition-transform duration-150"
            style={{
              width: 1180,
              height: 490,
              transform: `scale(${zoom})`,
            }}
          >
            {/* SVG Edges Layer */}
            <svg
              width={1180}
              height={490}
              className="pointer-events-none absolute inset-0"
              aria-hidden="true"
            >
              <defs>
                <marker
                  id="arrow-healthy"
                  viewBox="0 0 10 10"
                  refX="8"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#3f3f46" />
                </marker>
                <marker
                  id="arrow-fault"
                  viewBox="0 0 10 10"
                  refX="8"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#f59e0b" />
                </marker>
                <marker
                  id="arrow-critical"
                  viewBox="0 0 10 10"
                  refX="8"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#f43f5e" />
                </marker>
              </defs>

              {edges.map(({ from, to }) => {
                const x1 = from.position.x + NODE_W;
                const y1 = from.position.y + NODE_H / 2;
                const x2 = to.position.x - 4;
                const y2 = to.position.y + NODE_H / 2;
                const midX = (x1 + x2) / 2;

                const isHighlighted =
                  from.id === selectedService.id || to.id === selectedService.id;
                const isCrit = to.status === 'critical' || from.status === 'critical';
                const isFault = to.status === 'injecting' || from.status === 'injecting';

                const stroke = isCrit
                  ? '#f43f5e'
                  : isFault
                  ? '#f59e0b'
                  : isHighlighted
                  ? '#6366f1'
                  : '#3f3f46';

                const marker = isCrit
                  ? 'url(#arrow-critical)'
                  : isFault
                  ? 'url(#arrow-fault)'
                  : 'url(#arrow-healthy)';

                return (
                  <g key={`${from.id}->${to.id}`} opacity={isHighlighted || isCrit || isFault ? 0.95 : 0.55}>
                    <path
                      d={`M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`}
                      fill="none"
                      stroke={stroke}
                      strokeWidth={isHighlighted ? 2 : 1.4}
                      strokeDasharray={isFault || isCrit ? '5 4' : undefined}
                      markerEnd={marker}
                    />
                  </g>
                );
              })}
            </svg>

            {/* Interactive Nodes Layer */}
            {services.map((svc) => {
              const isSelected = svc.id === selectedService.id;
              const dimmed = tierFilter !== 'all' && svc.tier !== tierFilter;

              return (
                <button
                  key={svc.id}
                  type="button"
                  onClick={() => onSelectServiceId(svc.id)}
                  style={{
                    left: svc.position.x,
                    top: svc.position.y,
                    width: NODE_W,
                    height: NODE_H,
                    borderColor: statusBorder(svc, isSelected),
                  }}
                  className={`absolute flex flex-col justify-between rounded-lg border bg-[#18181b] p-2.5 text-left transition-all hover:bg-[#202024] ${
                    dimmed ? 'opacity-35' : 'opacity-100'
                  } ${svc.status === 'critical' ? 'fault-glow-crimson' : svc.status === 'injecting' ? 'fault-glow-amber' : ''} ${
                    isSelected ? 'ring-1 ring-[#6366f1]' : ''
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="truncate font-mono text-[12px] font-medium text-[#fafafa]">
                      {svc.name}
                    </span>
                    <StatusBadge status={svc.status} />
                  </div>

                  <div className="flex items-center justify-between font-mono text-[11px] tabular-nums">
                    <span className="text-[#a1a1aa]">
                      p99{' '}
                      <strong
                        className={
                          svc.p99Ms > svc.baseP99Ms * 2 ? 'text-[#f59e0b]' : 'text-[#fafafa]'
                        }
                      >
                        {svc.p99Ms.toFixed(0)}ms
                      </strong>
                    </span>
                    <span className="text-[#71717a]">{svc.rps.toLocaleString()} rps</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right: Persistent Contextual Inspector Sheet (380px on wide) */}
      <aside className="w-full shrink-0 overflow-y-auto border-t border-[#27272a] bg-[#111113] p-4 xl:w-[380px] xl:border-l xl:border-t-0">
        <div className="flex items-start justify-between gap-3 border-b border-[#27272a] pb-3">
          <div>
            <span className="font-mono text-[10px] uppercase tracking-[0.04em] text-[#71717a]">
              {selectedService.namespace} · {selectedService.tier}
            </span>
            <h2 className="mt-0.5 font-mono text-[15px] font-semibold text-[#fafafa]">
              {selectedService.name}
            </h2>
          </div>
          <StatusBadge status={selectedService.status} />
        </div>

        {/* Scalar Telemetry Grid */}
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div className="rounded border border-[#27272a] bg-[#18181b] p-2.5">
            <span className="block font-mono text-[10px] text-[#71717a]">p99 Latency</span>
            <span className="font-mono text-[16px] font-medium text-[#fafafa] tabular-nums">
              {selectedService.p99Ms.toFixed(1)} ms
            </span>
          </div>
          <div className="rounded border border-[#27272a] bg-[#18181b] p-2.5">
            <span className="block font-mono text-[10px] text-[#71717a]">5xx Error Rate</span>
            <span
              className={`font-mono text-[16px] font-medium tabular-nums ${
                selectedService.errorRatePct > 0.5 ? 'text-[#f43f5e]' : 'text-[#10b981]'
              }`}
            >
              {selectedService.errorRatePct.toFixed(2)}%
            </span>
          </div>
          <div className="rounded border border-[#27272a] bg-[#18181b] p-2.5">
            <span className="block font-mono text-[10px] text-[#71717a]">CPU Saturation</span>
            <span className="font-mono text-[14px] font-medium text-[#fafafa] tabular-nums">
              {selectedService.cpuPct}%
            </span>
          </div>
          <div className="rounded border border-[#27272a] bg-[#18181b] p-2.5">
            <span className="block font-mono text-[10px] text-[#71717a]">Pods Ready</span>
            <span className="font-mono text-[14px] font-medium text-[#fafafa] tabular-nums">
              {selectedService.podsReady}/{selectedService.podsTotal}
            </span>
          </div>
        </div>

        {/* Network & Deployment Coordinates */}
        <div className="mt-4 space-y-2 border-t border-[#27272a] pt-3 font-mono text-[11px]">
          <div className="flex justify-between">
            <span className="text-[#71717a]">Pod CIDR</span>
            <span className="text-[#fafafa] tabular-nums">{selectedService.cidr}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#71717a]">Image Tag</span>
            <span className="text-[#38bdf8]">{selectedService.version}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#71717a]">SLO Error Budget</span>
            <span className="text-[#fafafa] tabular-nums">
              {selectedService.sloBudgetRemainingPct.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Upstream & Downstream Mesh Links */}
        <div className="mt-4 space-y-3 border-t border-[#27272a] pt-3">
          <div>
            <span className="mb-1.5 block font-mono text-[10px] uppercase tracking-[0.04em] text-[#71717a]">
              Upstream Callers ({upstreamCallers.length})
            </span>
            <div className="flex flex-wrap gap-1.5">
              {upstreamCallers.length === 0 ? (
                <span className="font-mono text-[11px] text-[#71717a]">Edge ingress entry</span>
              ) : (
                upstreamCallers.map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => onSelectServiceId(u.id)}
                    className="rounded border border-[#27272a] bg-[#18181b] px-2 py-1 font-mono text-[11px] text-[#38bdf8] hover:bg-[#202024]"
                  >
                    {u.name}
                  </button>
                ))
              )}
            </div>
          </div>

          <div>
            <span className="mb-1.5 block font-mono text-[10px] uppercase tracking-[0.04em] text-[#71717a]">
              Downstream Targets ({downstreamDeps.length})
            </span>
            <div className="flex flex-wrap gap-1.5">
              {downstreamDeps.length === 0 ? (
                <span className="font-mono text-[11px] text-[#71717a]">Terminal persistence sink</span>
              ) : (
                downstreamDeps.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => onSelectServiceId(d.id)}
                    className="rounded border border-[#27272a] bg-[#18181b] px-2 py-1 font-mono text-[11px] text-[#fafafa] hover:bg-[#202024]"
                  >
                    {d.name}
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Node Fault Actions */}
        <div className="mt-4 space-y-2 border-t border-[#27272a] pt-3">
          <span className="block font-mono text-[10px] uppercase tracking-[0.04em] text-[#71717a]">
            Node Controls
          </span>

          {activeNodeExperiments.length > 0 && (
            <button
              type="button"
              onClick={() => onHaltServiceFaults(selectedService.id)}
              className="flex h-8 w-full items-center justify-center gap-1.5 rounded border border-[#f43f5e] bg-[#f43f5e]/15 font-mono text-[11px] font-medium text-[#f43f5e] hover:bg-[#f43f5e]/25 transition-colors"
            >
              <OctagonAlert className="h-3.5 w-3.5" />
              Halt {activeNodeExperiments.length} Active Fault(s)
            </button>
          )}

          <button
            type="button"
            onClick={() => onQuickInjectLatency(selectedService.id)}
            className="flex h-8 w-full items-center justify-center gap-1.5 rounded border border-white/10 bg-[#6366f1] font-mono text-[11px] font-medium text-[#fafafa] hover:bg-[#4f46e5] transition-colors"
          >
            <Flame className="h-3.5 w-3.5" />
            Inject +200ms Latency
          </button>

          <button
            type="button"
            onClick={() => onViewLogsForService(selectedService.name)}
            className="flex h-8 w-full items-center justify-center gap-1.5 rounded border border-[#27272a] bg-[#18181b] font-mono text-[11px] text-[#fafafa] hover:bg-[#202024] transition-colors"
          >
            <Terminal className="h-3.5 w-3.5 text-[#38bdf8]" />
            Stream Service Logs
          </button>
        </div>
      </aside>
    </div>
  );
};
