import React, { useMemo, useState } from 'react';
import { Flame, OctagonAlert, Play, RotateCcw } from 'lucide-react';
import { FAULT_TYPE_META } from '../data/mockTelemetry';
import { ChaosExperiment, ClusterId, FaultType, ServiceNode } from '../types/telemetry';
import { StatusBadge } from './StatusBadge';

interface ChaosLabScreenProps {
  cluster: ClusterId;
  services: ServiceNode[];
  experiments: ChaosExperiment[];
  onLaunchExperiment: (payload: {
    name: string;
    targetServiceId: string;
    faultType: FaultType;
    magnitude: number;
    blastRadiusPct: number;
    durationSec: number;
    hypothesis: string;
  }) => void;
  onHaltExperiment: (experimentId: string) => void;
  onInspectService: (service: ServiceNode) => void;
}

function formatCountdown(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const ChaosLabScreen: React.FC<ChaosLabScreenProps> = ({
  cluster,
  services,
  experiments,
  onLaunchExperiment,
  onHaltExperiment,
  onInspectService,
}) => {
  const [targetId, setTargetId] = useState<string>(services[2]?.id ?? services[0]?.id ?? '');
  const [faultType, setFaultType] = useState<FaultType>('latency');
  const [magnitude, setMagnitude] = useState<number>(FAULT_TYPE_META.latency.defaultVal);
  const [blastRadiusPct, setBlastRadiusPct] = useState<number>(30);
  const [durationSec, setDurationSec] = useState<number>(300);
  const [expName, setExpName] = useState<string>('');
  const [hypothesis, setHypothesis] = useState<string>(
    'Downstream retries stay bounded and circuit breaker isolates p99 spike within 5s.'
  );
  const [filterTab, setFilterTab] = useState<'all' | 'running' | 'completed' | 'halted'>('all');
  const [confirmHaltId, setConfirmHaltId] = useState<string | null>(null);

  const meta = FAULT_TYPE_META[faultType];
  const selectedService = services.find((s) => s.id === targetId) ?? services[0];

  const handleFaultTypeChange = (nextType: FaultType) => {
    setFaultType(nextType);
    setMagnitude(FAULT_TYPE_META[nextType].defaultVal);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService) return;
    const autoName =
      expName.trim() ||
      `${selectedService.name}-${faultType.replace('_', '-')}-${magnitude}${meta.unit.replace('/', '-')}`;
    onLaunchExperiment({
      name: autoName,
      targetServiceId: selectedService.id,
      faultType,
      magnitude,
      blastRadiusPct,
      durationSec,
      hypothesis: hypothesis.trim() || 'Steady-state SLO remains within error budget.',
    });
    setExpName('');
  };

  const filteredExperiments = useMemo(() => {
    return experiments.filter((exp) => filterTab === 'all' || exp.status === filterTab);
  }, [experiments, filterTab]);

  const runningCount = experiments.filter((e) => e.status === 'running').length;

  return (
    <div className="mx-auto max-w-[1440px] space-y-4 p-4 lg:p-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-[22px] font-semibold tracking-[-0.02em] text-[#fafafa]">
            Chaos Fault Lab
          </h1>
          <p className="mt-0.5 font-mono text-[11px] text-[#a1a1aa] tabular-nums">
            <span>{cluster}</span>
            <span className="mx-1.5 text-[#27272a]">·</span>
            <span>{runningCount} active injections</span>
            <span className="mx-1.5 text-[#27272a]">·</span>
            <span>blast guardrails armed</span>
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Left: Fault Injection Workbench (5 cols) */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-5 rounded-lg border border-[#27272a] bg-[#18181b] p-4 space-y-4 self-start"
        >
          <div className="flex items-center justify-between border-b border-[#27272a] pb-3">
            <div>
              <h2 className="font-display text-[15px] font-semibold text-[#fafafa]">
                Inject Synthetic Fault
              </h2>
              <p className="text-[12px] text-[#a1a1aa]">
                Mutates live mesh telemetry and downstream service spans
              </p>
            </div>
            <Flame className="h-4 w-4 text-[#f59e0b]" />
          </div>

          {/* Target Service */}
          <div>
            <label
              htmlFor="chaos-target-svc"
              className="mb-1.5 block font-mono text-[11px] text-[#a1a1aa]"
            >
              Target Service Selector
            </label>
            <select
              id="chaos-target-svc"
              value={targetId}
              onChange={(e) => setTargetId(e.target.value)}
              className="h-8 w-full rounded border border-[#27272a] bg-[#111113] px-2.5 font-mono text-[12px] text-[#fafafa] focus:border-[#6366f1] focus:outline-none"
            >
              {services.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.namespace}) — {s.podsReady}/{s.podsTotal} pods
                </option>
              ))}
            </select>
          </div>

          {/* Fault Vector Grid */}
          <div>
            <span className="mb-1.5 block font-mono text-[11px] text-[#a1a1aa]">Fault Vector</span>
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
              {(Object.keys(FAULT_TYPE_META) as FaultType[]).map((ft) => {
                const active = faultType === ft;
                return (
                  <button
                    key={ft}
                    type="button"
                    onClick={() => handleFaultTypeChange(ft)}
                    className={`h-8 rounded border px-2 font-mono text-[11px] transition-colors whitespace-nowrap truncate ${
                      active
                        ? 'border-[#6366f1] bg-[#6366f1]/15 text-[#fafafa]'
                        : 'border-[#27272a] bg-[#111113] text-[#a1a1aa] hover:bg-[#202024] hover:text-[#fafafa]'
                    }`}
                  >
                    {FAULT_TYPE_META[ft].label}
                  </button>
                );
              })}
            </div>
            <p className="mt-1.5 font-mono text-[11px] text-[#71717a]">{meta.desc}</p>
          </div>

          {/* Magnitude + Blast Radius Sliders */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <div className="mb-1 flex items-center justify-between font-mono text-[11px]">
                <span className="text-[#a1a1aa]">Magnitude</span>
                <span className="text-[#f59e0b] tabular-nums font-medium">
                  {magnitude} {meta.unit}
                </span>
              </div>
              <input
                type="range"
                min={meta.min}
                max={meta.max}
                step={meta.step}
                value={magnitude}
                onChange={(e) => setMagnitude(Number(e.target.value))}
                className="w-full accent-[#6366f1]"
              />
            </div>

            <div>
              <div className="mb-1 flex items-center justify-between font-mono text-[11px]">
                <span className="text-[#a1a1aa]">Blast Radius</span>
                <span className="text-[#38bdf8] tabular-nums font-medium">{blastRadiusPct}% pods</span>
              </div>
              <input
                type="range"
                min={10}
                max={100}
                step={5}
                value={blastRadiusPct}
                onChange={(e) => setBlastRadiusPct(Number(e.target.value))}
                className="w-full accent-[#6366f1]"
              />
            </div>
          </div>

          {/* Duration & Experiment Slug */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <span className="mb-1.5 block font-mono text-[11px] text-[#a1a1aa]">Duration</span>
              <div className="flex items-center rounded border border-[#27272a] bg-[#111113] p-0.5">
                {[120, 300, 600].map((sec) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => setDurationSec(sec)}
                    className={`h-6 flex-1 rounded-[3px] font-mono text-[11px] tabular-nums transition-colors ${
                      durationSec === sec
                        ? 'bg-[#202024] text-[#fafafa]'
                        : 'text-[#71717a] hover:text-[#a1a1aa]'
                    }`}
                  >
                    {sec / 60}m
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label
                htmlFor="chaos-exp-name"
                className="mb-1.5 block font-mono text-[11px] text-[#a1a1aa]"
              >
                Experiment Identifier
              </label>
              <input
                id="chaos-exp-name"
                type="text"
                value={expName}
                onChange={(e) => setExpName(e.target.value)}
                placeholder="auto-generated if blank"
                className="h-8 w-full rounded border border-[#27272a] bg-[#111113] px-2.5 font-mono text-[12px] text-[#fafafa] placeholder:text-[#71717a] focus:border-[#6366f1] focus:outline-none"
              />
            </div>
          </div>

          {/* Hypothesis */}
          <div>
            <label
              htmlFor="chaos-hypothesis"
              className="mb-1.5 block font-mono text-[11px] text-[#a1a1aa]"
            >
              Steady-State Hypothesis
            </label>
            <textarea
              id="chaos-hypothesis"
              rows={2}
              value={hypothesis}
              onChange={(e) => setHypothesis(e.target.value)}
              className="w-full rounded border border-[#27272a] bg-[#111113] p-2.5 text-[12px] text-[#fafafa] placeholder:text-[#71717a] focus:border-[#6366f1] focus:outline-none"
            />
          </div>

          {/* Blast Preview Strip */}
          {selectedService && (
            <div className="flex items-center justify-between rounded border border-[#27272a] bg-[#111113] px-3 py-2 font-mono text-[11px] tabular-nums">
              <span className="text-[#a1a1aa]">
                Affected replicas:{' '}
                <strong className="text-[#fafafa]">
                  {Math.max(1, Math.round((selectedService.podsTotal * blastRadiusPct) / 100))}/
                  {selectedService.podsTotal}
                </strong>
              </span>
              <span className="text-[#71717a]">
                Est. traffic: {Math.round((selectedService.rps * blastRadiusPct) / 100).toLocaleString()} rps
              </span>
            </div>
          )}

          <button
            type="submit"
            className="flex h-9 w-full items-center justify-center gap-2 rounded border border-white/10 bg-[#6366f1] px-4 text-[13px] font-medium text-[#fafafa] hover:bg-[#4f46e5] transition-colors"
          >
            <Play className="h-3.5 w-3.5" />
            Launch Fault Experiment
          </button>
        </form>

        {/* Right: Experiments Queue & History (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[#27272a] bg-[#18181b] px-4 py-2.5">
            <span className="font-display text-[15px] font-semibold text-[#fafafa]">
              Experiment Ledger
            </span>
            <div className="flex items-center rounded border border-[#27272a] bg-[#111113] p-0.5">
              {(['all', 'running', 'completed', 'halted'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setFilterTab(tab)}
                  className={`h-6 rounded-[3px] px-2.5 font-mono text-[10px] uppercase tracking-[0.04em] transition-colors whitespace-nowrap shrink-0 ${
                    filterTab === tab
                      ? 'bg-[#202024] text-[#fafafa]'
                      : 'text-[#71717a] hover:text-[#a1a1aa]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredExperiments.length === 0 ? (
              <div className="rounded-lg border border-[#27272a] bg-[#18181b] p-8 text-center font-mono text-[12px] text-[#71717a]">
                No experiments in this state.
              </div>
            ) : (
              filteredExperiments.map((exp) => {
                const isRunning = exp.status === 'running';
                const targetSvc = services.find((s) => s.id === exp.targetServiceId);
                const confirming = confirmHaltId === exp.id;

                return (
                  <div
                    key={exp.id}
                    className={`rounded-lg border bg-[#18181b] p-4 transition-colors ${
                      isRunning ? 'border-[#f59e0b]/40 fault-glow-amber' : 'border-[#27272a]'
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <StatusBadge status={exp.status} />
                          <h3 className="font-mono text-[13px] font-medium text-[#fafafa] truncate">
                            {exp.name}
                          </h3>
                        </div>
                        <p className="font-mono text-[11px] text-[#a1a1aa] tabular-nums">
                          <span>{exp.id}</span>
                          <span className="mx-1.5 text-[#27272a]">·</span>
                          <button
                            type="button"
                            onClick={() => targetSvc && onInspectService(targetSvc)}
                            className="text-[#38bdf8] hover:underline"
                          >
                            {exp.targetServiceName}
                          </button>
                          <span className="mx-1.5 text-[#27272a]">·</span>
                          <span>{FAULT_TYPE_META[exp.faultType].label}</span>
                          <span className="mx-1.5 text-[#27272a]">·</span>
                          <span className="text-[#fafafa]">
                            {exp.magnitude}
                            {exp.magnitudeUnit} ({exp.blastRadiusPct}% blast)
                          </span>
                        </p>
                      </div>

                      {/* Right Actions & Countdown */}
                      <div className="flex items-center gap-2 shrink-0">
                        {isRunning ? (
                          <>
                            <div className="rounded border border-[#27272a] bg-[#111113] px-2.5 py-1 font-mono text-[12px] text-[#f59e0b] tabular-nums">
                              T-{formatCountdown(exp.remainingSec)}
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                if (!confirming) {
                                  setConfirmHaltId(exp.id);
                                  setTimeout(() => setConfirmHaltId(null), 3500);
                                } else {
                                  setConfirmHaltId(null);
                                  onHaltExperiment(exp.id);
                                }
                              }}
                              className={`flex h-8 items-center gap-1.5 rounded px-2.5 font-mono text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                                confirming
                                  ? 'bg-[#f43f5e] text-white border border-[#f43f5e]'
                                  : 'border border-[#f43f5e]/60 bg-[#f43f5e]/10 text-[#f43f5e] hover:bg-[#f43f5e]/20'
                              }`}
                            >
                              <OctagonAlert className="h-3.5 w-3.5" />
                              {confirming ? 'Confirm Halt' : 'Halt'}
                            </button>
                          </>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              onLaunchExperiment({
                                name: `${exp.name}-replay`,
                                targetServiceId: exp.targetServiceId,
                                faultType: exp.faultType,
                                magnitude: exp.magnitude,
                                blastRadiusPct: exp.blastRadiusPct,
                                durationSec: exp.durationSec,
                                hypothesis: exp.hypothesis,
                              })
                            }
                            className="flex h-7 items-center gap-1.5 rounded border border-[#27272a] bg-[#111113] px-2.5 font-mono text-[11px] text-[#a1a1aa] hover:bg-[#202024] hover:text-[#fafafa] transition-colors whitespace-nowrap shrink-0"
                          >
                            <RotateCcw className="h-3 w-3" />
                            Re-run
                          </button>
                        )}
                      </div>
                    </div>

                    <p className="mt-2.5 text-[12px] text-[#a1a1aa]">{exp.hypothesis}</p>

                    {/* Footer Telemetry Strip */}
                    <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#27272a] pt-2.5 font-mono text-[11px] text-[#71717a] tabular-nums">
                      <span>Started {exp.startedAt}</span>
                      <span>
                        Observed p99 impact:{' '}
                        <span className={exp.impactDeltaP99Pct > 50 ? 'text-[#f59e0b]' : 'text-[#10b981]'}>
                          +{exp.impactDeltaP99Pct.toFixed(1)}%
                        </span>
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
