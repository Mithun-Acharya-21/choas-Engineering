import React from 'react';
import {
  Activity,
  ChevronLeft,
  ChevronRight,
  Flame,
  Network,
  Pause,
  Play,
  Terminal,
} from 'lucide-react';
import { CLUSTERS } from '../data/mockTelemetry';
import { ClusterId, ScreenId } from '../types/telemetry';

interface SidebarProps {
  activeScreen: ScreenId;
  onSelectScreen: (screen: ScreenId) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  cluster: ClusterId;
  onSelectCluster: (cluster: ClusterId) => void;
  runningFaultCount: number;
  isLive: boolean;
  onToggleLive: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: { id: ScreenId; label: string; icon: React.ElementType; shortcut: string }[] = [
  { id: 'telemetry', label: 'Telemetry', icon: Activity, shortcut: '1' },
  { id: 'chaos', label: 'Chaos Lab', icon: Flame, shortcut: '2' },
  { id: 'topology', label: 'Topology', icon: Network, shortcut: '3' },
  { id: 'logs', label: 'Logs & Traces', icon: Terminal, shortcut: '4' },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeScreen,
  onSelectScreen,
  collapsed,
  onToggleCollapse,
  cluster,
  onSelectCluster,
  runningFaultCount,
  isLive,
  onToggleLive,
  mobileOpen,
  onCloseMobile,
}) => {
  const content = (
    <aside
      className={`flex h-full flex-col border-r border-[#27272a] bg-[#111113] transition-[width] duration-150 ${
        collapsed ? 'w-16' : 'w-60'
      }`}
    >
      {/* Brand Row */}
      <div className="flex h-12 items-center justify-between border-b border-[#27272a] px-3.5">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded border border-[#27272a] bg-[#18181b] text-[#c0c1ff]">
            <svg width="15" height="15" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path
                d="M8 1.5L14 5V11L8 14.5L2 11V5L8 1.5Z"
                stroke="currentColor"
                strokeWidth="1.4"
              />
              <circle cx="8" cy="8" r="2" fill="#6366f1" />
            </svg>
          </div>
          {!collapsed && (
            <span className="font-display text-[14px] font-semibold tracking-tight text-[#fafafa] whitespace-nowrap">
              Obsidian
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={onToggleCollapse}
          aria-label={collapsed ? 'Expand navigation' : 'Collapse navigation'}
          className="hidden lg:flex h-6 w-6 items-center justify-center rounded text-[#71717a] hover:bg-[#202024] hover:text-[#fafafa] transition-colors"
        >
          {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
        </button>
      </div>

      {/* Cluster Context Switcher */}
      <div className="border-b border-[#27272a] p-2.5">
        {!collapsed ? (
          <div>
            <label
              htmlFor="cluster-select"
              className="mb-1.5 block px-1 font-mono text-[10px] font-medium uppercase tracking-[0.04em] text-[#71717a]"
            >
              Target Cluster
            </label>
            <select
              id="cluster-select"
              value={cluster}
              onChange={(e) => onSelectCluster(e.target.value as ClusterId)}
              className="h-8 w-full rounded border border-[#27272a] bg-[#09090b] px-2 font-mono text-[12px] text-[#fafafa] focus:border-[#6366f1] focus:outline-none"
            >
              {CLUSTERS.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.id}
                </option>
              ))}
            </select>
          </div>
        ) : (
          <button
            type="button"
            onClick={onToggleCollapse}
            title={`Cluster: ${cluster}`}
            className="mx-auto flex h-8 w-9 items-center justify-center rounded border border-[#27272a] bg-[#09090b] font-mono text-[10px] text-[#38bdf8] hover:border-[#6366f1]"
          >
            US
          </button>
        )}
      </div>

      {/* Primary Workspace Navigation */}
      <nav className="flex-1 space-y-1 p-2" aria-label="Primary Workspace">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = activeScreen === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onSelectScreen(item.id);
                onCloseMobile();
              }}
              title={collapsed ? item.label : undefined}
              className={`group flex h-9 w-full items-center rounded px-2.5 text-[13px] font-medium transition-colors whitespace-nowrap ${
                active
                  ? 'bg-[#202024] text-[#fafafa] shadow-[inset_0_0_0_1px_#27272a]'
                  : 'text-[#a1a1aa] hover:bg-[#18181b] hover:text-[#fafafa]'
              } ${collapsed ? 'justify-center px-0' : 'justify-between'}`}
            >
              <span className="flex items-center gap-2.5 min-w-0">
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    active ? 'text-[#6366f1]' : 'text-[#71717a] group-hover:text-[#a1a1aa]'
                  }`}
                />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </span>
              {!collapsed && (
                <span className="flex items-center gap-1.5">
                  {item.id === 'chaos' && runningFaultCount > 0 && (
                    <span className="inline-flex h-4 min-w-[18px] items-center justify-center rounded bg-[#f59e0b]/15 px-1 font-mono text-[10px] font-medium tabular-nums text-[#f59e0b] border border-[#f59e0b]/30">
                      {runningFaultCount}
                    </span>
                  )}
                  <span className="font-mono text-[10px] text-[#71717a]">G{item.shortcut}</span>
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Live Stream Control */}
      <div className="border-t border-[#27272a] p-2.5">
        <button
          type="button"
          onClick={onToggleLive}
          className={`flex h-8 w-full items-center rounded border px-2.5 font-mono text-[11px] transition-colors whitespace-nowrap ${
            isLive
              ? 'border-[#10b981]/30 bg-[#10b981]/10 text-[#10b981] hover:bg-[#10b981]/15'
              : 'border-[#27272a] bg-[#18181b] text-[#a1a1aa] hover:bg-[#202024] hover:text-[#fafafa]'
          } ${collapsed ? 'justify-center px-0' : 'justify-between'}`}
          title={isLive ? 'Pause live telemetry stream' : 'Resume live telemetry stream'}
        >
          <span className="flex items-center gap-2">
            {isLive ? <Pause className="h-3 w-3 shrink-0" /> : <Play className="h-3 w-3 shrink-0" />}
            {!collapsed && <span>{isLive ? 'Streaming Live' : 'Stream Paused'}</span>}
          </span>
          {!collapsed && (
            <span className="tabular-nums text-[10px] opacity-80">{isLive ? '2s' : 'OFF'}</span>
          )}
        </button>
      </div>
    </aside>
  );

  return (
    <>
      <div className="hidden md:block h-full shrink-0">{content}</div>
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div
            className="fixed inset-0 bg-black/70"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative z-10 h-full">{content}</div>
        </div>
      )}
    </>
  );
};
