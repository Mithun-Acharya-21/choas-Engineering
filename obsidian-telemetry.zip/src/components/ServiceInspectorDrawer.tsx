import React from 'react';
import { Flame, Network, OctagonAlert, Terminal, X } from 'lucide-react';
import { ChaosExperiment, ServiceNode } from '../types/telemetry';
import { StatusBadge } from './StatusBadge';

interface ServiceInspectorDrawerProps {
  service: ServiceNode | null;
  experiments: ChaosExperiment[];
  onClose: () => void;
  onQuickInjectLatency: (serviceId: string) => void;
  onHaltServiceFaults: (serviceId: string) => void;
  onOpenTopology: (serviceId: string) => void;
  onOpenLogs: (serviceName: string) => void;
}

export const ServiceInspectorDrawer: React.FC<ServiceInspectorDrawerProps> = ({
  service,
  experiments,
  onClose,
  onQuickInjectLatency,
  onHaltServiceFaults,
  onOpenTopology,
  onOpenLogs,
}) => {
  if (!service) return null;

  const activeExps = experiments.filter(
    (e) => e.status === 'running' && e.targetServiceId === service.id
  );

  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="fixed inset-0 bg-black/60" onClick={onClose} aria-hidden="true" />
      <aside className="relative z-10 flex h-full w-full max-w-[400px] flex-col border-l border-[#27272a] bg-[#111113] p-5 overflow-y-auto overlay-elevation">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 border-b border-[#27272a] pb-4">
          <div>
            <span className="font-mono text-[10px] uppercase tracking-[0.04em] text-[#71717a]">
              {service.cluster} · {service.namespace}
            </span>
            <h2 className="mt-1 font-mono text-[16px] font-semibold text-[#fafafa]">
              {service.name}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge status={service.status} />
            <button
              type="button"
              onClick={onClose}
              aria-label="Close service inspector"
              className="flex h-7 w-7 items-center justify-center rounded border border-[#27272a] bg-[#18181b] text-[#a1a1aa] hover:bg-[#202024] hover:text-[#fafafa]"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Latency Percentiles */}
        <div className="mt-4 grid grid-cols-3 gap-2">
          <div className="rounded border border-[#27272a] bg-[#18181b] p-2.5">
            <span className="block font-mono text-[10px] text-[#71717a]">p50</span>
            <span className="font-mono text-[14px] font-medium text-[#fafafa] tabular-nums">
              {service.p50Ms.toFixed(1)}ms
            </span>
          </div>
          <div className="rounded border border-[#27272a] bg-[#18181b] p-2.5">
            <span className="block font-mono text-[10px] text-[#71717a]">p95</span>
            <span className="font-mono text-[14px] font-medium text-[#fafafa] tabular-nums">
              {service.p95Ms.toFixed(1)}ms
            </span>
          </div>
          <div className="rounded border border-[#27272a] bg-[#18181b] p-2.5">
            <span className="block font-mono text-[10px] text-[#71717a]">p99</span>
            <span
              className={`font-mono text-[14px] font-medium tabular-nums ${
                service.p99Ms > service.baseP99Ms * 2 ? 'text-[#f59e0b]' : 'text-[#fafafa]'
              }`}
            >
              {service.p99Ms.toFixed(1)}ms
            </span>
          </div>
        </div>

        {/* Resource Utilization Bars */}
        <div className="mt-4 space-y-3 rounded border border-[#27272a] bg-[#18181b] p-3">
          <div>
            <div className="mb-1 flex justify-between font-mono text-[11px] tabular-nums">
              <span className="text-[#a1a1aa]">CPU Quota Usage</span>
              <span className="text-[#fafafa]">{service.cpuPct}%</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-[2px] bg-[#09090b]">
              <div
                className={`h-full ${service.cpuPct > 80 ? 'bg-[#f43f5e]' : 'bg-[#6366f1]'}`}
                style={{ width: `${service.cpuPct}%` }}
              />
            </div>
          </div>

          <div>
            <div className="mb-1 flex justify-between font-mono text-[11px] tabular-nums">
              <span className="text-[#a1a1aa]">Memory RSS</span>
              <span className="text-[#fafafa]">{service.memoryPct}%</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-[2px] bg-[#09090b]">
              <div className="h-full bg-[#38bdf8]" style={{ width: `${service.memoryPct}%` }} />
            </div>
          </div>
        </div>

        {/* Runtime Metadata */}
        <div className="mt-4 space-y-2 border-t border-[#27272a] pt-3 font-mono text-[11px]">
          <div className="flex justify-between">
            <span className="text-[#71717a]">Pod Replicas</span>
            <span className="text-[#fafafa] tabular-nums">
              {service.podsReady} / {service.podsTotal} ready
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#71717a]">Cluster CIDR</span>
            <span className="text-[#fafafa] tabular-nums">{service.cidr}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#71717a]">Release Version</span>
            <span className="text-[#38bdf8]">{service.version}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#71717a]">5xx Error Rate</span>
            <span
              className={`tabular-nums ${
                service.errorRatePct > 0.5 ? 'text-[#f43f5e]' : 'text-[#10b981]'
              }`}
            >
              {service.errorRatePct.toFixed(2)}%
            </span>
          </div>
        </div>

        {/* Active Faults on Target */}
        {activeExps.length > 0 && (
          <div className="mt-4 space-y-2 rounded border border-[#f59e0b]/35 bg-[#f59e0b]/10 p-3">
            <div className="font-mono text-[11px] font-medium text-[#f59e0b]">
              Active Fault Injections ({activeExps.length})
            </div>
            {activeExps.map((exp) => (
              <div key={exp.id} className="font-mono text-[11px] text-[#fafafa] tabular-nums">
                {exp.name} · {exp.magnitude}
                {exp.magnitudeUnit} · T-{exp.remainingSec}s
              </div>
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="mt-auto space-y-2 pt-5">
          {activeExps.length > 0 && (
            <button
              type="button"
              onClick={() => onHaltServiceFaults(service.id)}
              className="flex h-8 w-full items-center justify-center gap-1.5 rounded border border-[#f43f5e] bg-[#f43f5e]/15 font-mono text-[11px] font-medium text-[#f43f5e] hover:bg-[#f43f5e]/25"
            >
              <OctagonAlert className="h-3.5 w-3.5" />
              Halt Node Faults
            </button>
          )}
          <button
            type="button"
            onClick={() => onQuickInjectLatency(service.id)}
            className="flex h-8 w-full items-center justify-center gap-1.5 rounded border border-white/10 bg-[#6366f1] font-mono text-[11px] font-medium text-[#fafafa] hover:bg-[#4f46e5]"
          >
            <Flame className="h-3.5 w-3.5" />
            Inject +200ms Latency
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                onOpenTopology(service.id);
                onClose();
              }}
              className="flex h-8 items-center justify-center gap-1.5 rounded border border-[#27272a] bg-[#18181b] font-mono text-[11px] text-[#fafafa] hover:bg-[#202024]"
            >
              <Network className="h-3.5 w-3.5 text-[#38bdf8]" />
              Topology
            </button>
            <button
              type="button"
              onClick={() => {
                onOpenLogs(service.name);
                onClose();
              }}
              className="flex h-8 items-center justify-center gap-1.5 rounded border border-[#27272a] bg-[#18181b] font-mono text-[11px] text-[#fafafa] hover:bg-[#202024]"
            >
              <Terminal className="h-3.5 w-3.5 text-[#38bdf8]" />
              Logs
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
};
